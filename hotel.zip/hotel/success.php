<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Status </title>

    <link rel="stylesheet" href="css/success-style.css">
</head>
<body>
    <h1>Your Booking is Successfull !</h1>
    <h2><a href="http://localhost/phpmyadmin/sql.php?db=dc2019mca0009&table=room_details&pos=0">Click in the link </a>to view Data on <span>phpmyadmin Database</span> . </h2>
</body>
</html>