<?php
	$servername = "localhost";
	$username="root";
	$password="";
	$dbname="dc2019mca0009";
	
	$con =mysqli_connect($servername, $username,$password,$dbname);
?>